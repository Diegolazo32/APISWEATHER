const request = require('request');//Paquete requerido

const options = {
    url: //'http://api.openweathermap.org/geo/1.0/direct?q=usulutan,&&appid=78a21ef19440fd21f659455f994e9e78',
    'https://api.openweathermap.org/data/2.5/weather?lat={13.3438204}&lon={-88.4382264}&appid={78a21ef19440fd21f659455f994e9e78}',
    method: 'GET',
    headers: {
        'Accept': 'application/json',
        'Accept-Charset': 'utf-8',
        'User-Agent': 'Weather'
    }
};

request(options, function(err, res, body) {
    let json = JSON.parse(body);
    // imprimir código de estado.
    console.log(json);
});